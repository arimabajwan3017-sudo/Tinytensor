# tinytensor

**A small, dependency-free deep-learning runtime in C — built to make memory,
compute, and numerical behavior visible.**

`tinytensor` is an educational systems project. The initial `v0.1` foundation
contains contiguous N-dimensional float32 tensors, a bump arena allocator,
basic tensor operations, stable softmax, cross-entropy, and cache-blocked
matrix multiplication.

> Status: early development. This is not yet a complete neural-network trainer.
> Autograd, optimizers, serialization, and int8 inference are roadmap items.

## Features

- N-dimensional tensor shape and stride metadata (contiguous row-major storage)
- Heap and arena-backed allocation
- Add, ReLU, softmax, and cross-entropy
- Cache-blocked 2-D matrix multiplication
- CMake build, unit tests, demo, benchmark harness, and GitHub Actions CI

## Build

Requirements: a C11 compiler, CMake 3.16+, and the platform math library.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

Run the demo and microbenchmark:

```bash
./build/matmul_demo
./build/matmul_bench
```

Enable AddressSanitizer and UBSan (GCC/Clang):

```bash
cmake -S . -B build-asan -DTT_ENABLE_SANITIZERS=ON -DCMAKE_BUILD_TYPE=Debug
cmake --build build-asan --parallel
ctest --test-dir build-asan --output-on-failure
```

## Quick API example

```c
size_t a_shape[] = {2, 3};
size_t b_shape[] = {3, 2};
size_t out_shape[] = {2, 2};
tt_tensor a, b, out;

tt_tensor_create(&a, 2, a_shape);
tt_tensor_create(&b, 2, b_shape);
tt_tensor_create(&out, 2, out_shape);

tt_matmul(&a, &b, &out);

tt_tensor_free(&a);
tt_tensor_free(&b);
tt_tensor_free(&out);
```

Check every returned `tt_status` in production code. The example is abbreviated.

## Repository layout

```text
include/tinytensor/   Public C API
src/                 Allocator, tensor metadata, and operations
tests/               Unit tests
examples/            Small executable examples
bench/               Microbenchmarks (not framework comparisons)
docs/                Design notes and roadmap
.github/workflows/   Build/test CI
```

## Benchmarking honestly

The included benchmark measures only the local matrix multiplication kernel.
It is not a PyTorch comparison and does not measure peak resident memory.
Record compiler, flags, CPU model, OS, dimensions, warm-up policy, and repeated
run statistics before publishing performance claims. Do not fill the MNIST
accuracy table with estimates; add results only after running the same model
and dataset split under documented conditions.

## Memory ownership

- `tt_tensor_create`: heap allocation; release with `tt_tensor_free`.
- `tt_tensor_create_in_arena`: arena allocation; descriptor can be freed, but
  storage is reclaimed only by `tt_arena_reset` or `tt_arena_free`.
- Resetting/destroying an arena invalidates its tensors.

## Contributing

Start with `docs/roadmap.md`. New operations should include shape validation,
unit tests, and numerical edge-case tests. Keep compiler warnings clean.

## License

MIT — see `LICENSE`.

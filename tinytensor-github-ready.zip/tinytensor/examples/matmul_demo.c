#include "tinytensor/tinytensor.h"
#include <stdio.h>

int main(void) {
    size_t as[] = {2, 3}, bs[] = {3, 2}, os[] = {2, 2};
    tt_tensor a, b, out;
    if (tt_tensor_create(&a, 2, as) != TT_OK ||
        tt_tensor_create(&b, 2, bs) != TT_OK ||
        tt_tensor_create(&out, 2, os) != TT_OK) {
        fprintf(stderr, "tensor allocation failed\n");
        return 1;
    }
    float av[] = {1,2,3,4,5,6}, bv[] = {7,8,9,10,11,12};
    for (size_t i=0;i<6;i++){a.data[i]=av[i];b.data[i]=bv[i];}
    if (tt_matmul(&a,&b,&out) != TT_OK) return 1;
    printf("[[%g, %g],\\n [%g, %g]]\\n",
           out.data[0],out.data[1],out.data[2],out.data[3]);
    tt_tensor_free(&a); tt_tensor_free(&b); tt_tensor_free(&out);
    return 0;
}

# Roadmap

- [x] Phase 1 foundation: tensor metadata, arena, core ops, blocked matmul, tests
- [ ] Phase 2: autograd graph, gradient checks, dense layers, SGD/Adam, XOR
- [ ] Phase 3: binary serialization, int8 calibration/quantization, accuracy-size-latency report
- [ ] Phase 4: pthread/OpenMP, SIMD, profiler results, expanded CI and documentation

A checkbox should only be marked complete after implementation and tests land.

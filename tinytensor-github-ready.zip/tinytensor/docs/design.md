# Design notes

## Scope of v0.1

This first repository cut implements contiguous row-major float32 tensors, a bump
arena allocator, elementwise add/ReLU/softmax, cross-entropy, and blocked 2-D
matrix multiplication. It deliberately does not claim to be a complete training
framework yet.

## Tensor and memory model

A tensor stores a data pointer, rank, shape, strides, element count, and an
ownership flag. Strides are measured in elements. The current constructors
create contiguous row-major tensors; explicit non-contiguous views are planned.

Heap tensors own their allocation and must be released with `tt_tensor_free`.
Arena tensors borrow their storage; freeing their descriptor does not release
arena memory. Resetting an arena invalidates every tensor allocated from it.
Do not use arena-backed tensors after reset or arena destruction.

## Matrix multiplication

The baseline kernel computes C = A × B for rank-2 tensors. The loop nest is
blocked in M, K, and N tiles (tile size 32) to improve cache locality. This is
a portable scalar C implementation, not an AVX/NEON kernel.

## Numerical behavior

Softmax is computed independently across the final dimension and subtracts the
row maximum before exponentiation for improved numerical stability.
Cross-entropy expects probabilities and integer class labels; it clips selected
probabilities to 1e-7 before taking the logarithm.

## Planned evolution

- Add explicit tensor views and broadcasting rules.
- Add a graph/tape representation and reverse-mode gradients.
- Add finite-difference gradient checks before optimizers.
- Add model I/O, quantization, and reproducible dataset benchmarks.

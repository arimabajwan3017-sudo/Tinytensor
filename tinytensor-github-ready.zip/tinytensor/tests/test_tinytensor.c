#include "tinytensor/tinytensor.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define CHECK(expr) do { if (!(expr)) { \
    fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #expr); return 1; \
} } while (0)
#define NEAR(a,b,e) (fabsf((a)-(b)) <= (e))

static int test_matmul(void) {
    size_t sa[] = {2, 3}, sb[] = {3, 2}, so[] = {2, 2};
    tt_tensor a, b, o;
    CHECK(tt_tensor_create(&a, 2, sa) == TT_OK);
    CHECK(tt_tensor_create(&b, 2, sb) == TT_OK);
    CHECK(tt_tensor_create(&o, 2, so) == TT_OK);
    float av[] = {1,2,3,4,5,6}, bv[] = {7,8,9,10,11,12};
    for (size_t i=0;i<6;i++){a.data[i]=av[i];b.data[i]=bv[i];}
    CHECK(tt_matmul(&a,&b,&o) == TT_OK);
    CHECK(NEAR(o.data[0],58,1e-5f) && NEAR(o.data[1],64,1e-5f));
    CHECK(NEAR(o.data[2],139,1e-5f) && NEAR(o.data[3],154,1e-5f));
    tt_tensor_free(&a); tt_tensor_free(&b); tt_tensor_free(&o);
    return 0;
}
static int test_ops(void) {
    size_t s[] = {1,3};
    tt_tensor a,b,c;
    CHECK(tt_tensor_create(&a,2,s)==TT_OK);
    CHECK(tt_tensor_create(&b,2,s)==TT_OK);
    CHECK(tt_tensor_create(&c,2,s)==TT_OK);
    a.data[0]=-1; a.data[1]=0; a.data[2]=2;
    CHECK(tt_relu(&a,&b)==TT_OK);
    CHECK(b.data[0]==0 && b.data[1]==0 && b.data[2]==2);
    CHECK(tt_add(&a,&b,&c)==TT_OK);
    CHECK(c.data[0]==-1 && c.data[2]==4);
    CHECK(tt_softmax(&a,&b)==TT_OK);
    CHECK(NEAR(b.data[0]+b.data[1]+b.data[2],1.0f,1e-5f));
    tt_tensor_free(&a);tt_tensor_free(&b);tt_tensor_free(&c);
    return 0;
}
static int test_arena(void) {
    tt_arena arena;
    CHECK(tt_arena_init(&arena, 1024)==TT_OK);
    size_t s[]={4,4}; tt_tensor t;
    CHECK(tt_tensor_create_in_arena(&t,&arena,2,s)==TT_OK);
    CHECK(t.numel==16 && !t.owns_data);
    tt_tensor_free(&t);
    tt_arena_reset(&arena);
    tt_arena_free(&arena);
    return 0;
}
int main(void) {
    CHECK(test_matmul()==0);
    CHECK(test_ops()==0);
    CHECK(test_arena()==0);
    puts("All tinytensor tests passed.");
    return 0;
}

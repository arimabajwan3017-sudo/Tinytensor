cmake_minimum_required(VERSION 3.16)
project(tinytensor VERSION 0.1.0 LANGUAGES C)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS OFF)

option(TT_ENABLE_SANITIZERS "Enable AddressSanitizer and UBSan" OFF)

add_library(tinytensor
    src/alloc.c
    src/tensor.c
    src/ops/ops.c
)
target_include_directories(tinytensor PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_options(tinytensor PRIVATE -Wall -Wextra -Wpedantic -Werror)
if(NOT MSVC)
    target_link_libraries(tinytensor PUBLIC m)
endif()

if(TT_ENABLE_SANITIZERS AND CMAKE_C_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(tinytensor PUBLIC -fsanitize=address,undefined -fno-omit-frame-pointer)
    target_link_options(tinytensor PUBLIC -fsanitize=address,undefined)
endif()

enable_testing()
add_executable(test_tinytensor tests/test_tinytensor.c)
target_link_libraries(test_tinytensor PRIVATE tinytensor)
target_compile_options(test_tinytensor PRIVATE -Wall -Wextra -Wpedantic -Werror)
add_test(NAME tinytensor_unit_tests COMMAND test_tinytensor)

add_executable(matmul_demo examples/matmul_demo.c)
target_link_libraries(matmul_demo PRIVATE tinytensor)
target_compile_options(matmul_demo PRIVATE -Wall -Wextra -Wpedantic -Werror)

add_executable(matmul_bench bench/matmul_bench.c)
target_link_libraries(matmul_bench PRIVATE tinytensor)
target_compile_options(matmul_bench PRIVATE -Wall -Wextra -Wpedantic -Werror)

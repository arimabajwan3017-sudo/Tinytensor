#include "tinytensor/tinytensor.h"
#include <math.h>

static bool same_shape(const tt_tensor *a, const tt_tensor *b) {
    if (!a || !b || a->ndim != b->ndim) return false;
    for (size_t i = 0; i < a->ndim; ++i)
        if (a->shape[i] != b->shape[i]) return false;
    return true;
}

tt_status tt_add(const tt_tensor *a, const tt_tensor *b, tt_tensor *out) {
    if (!a || !b || !out || !a->data || !b->data || !out->data)
        return TT_ERR_INVALID_ARGUMENT;
    if (!same_shape(a, b) || !same_shape(a, out)) return TT_ERR_SHAPE;
    for (size_t i = 0; i < a->numel; ++i) out->data[i] = a->data[i] + b->data[i];
    return TT_OK;
}

tt_status tt_relu(const tt_tensor *in, tt_tensor *out) {
    if (!in || !out || !in->data || !out->data) return TT_ERR_INVALID_ARGUMENT;
    if (!same_shape(in, out)) return TT_ERR_SHAPE;
    for (size_t i = 0; i < in->numel; ++i)
        out->data[i] = in->data[i] > 0.0f ? in->data[i] : 0.0f;
    return TT_OK;
}

tt_status tt_softmax(const tt_tensor *in, tt_tensor *out) {
    if (!in || !out || !in->data || !out->data) return TT_ERR_INVALID_ARGUMENT;
    if (!same_shape(in, out) || in->ndim < 1) return TT_ERR_SHAPE;
    size_t classes = in->shape[in->ndim - 1];
    size_t rows = in->numel / classes;
    for (size_t r = 0; r < rows; ++r) {
        float maxv = in->data[r * classes];
        for (size_t j = 1; j < classes; ++j)
            if (in->data[r * classes + j] > maxv) maxv = in->data[r * classes + j];
        float sum = 0.0f;
        for (size_t j = 0; j < classes; ++j) {
            float e = expf(in->data[r * classes + j] - maxv);
            out->data[r * classes + j] = e;
            sum += e;
        }
        for (size_t j = 0; j < classes; ++j)
            out->data[r * classes + j] /= sum;
    }
    return TT_OK;
}

tt_status tt_matmul(const tt_tensor *a, const tt_tensor *b, tt_tensor *out) {
    if (!a || !b || !out || !a->data || !b->data || !out->data)
        return TT_ERR_INVALID_ARGUMENT;
    if (a->ndim != 2 || b->ndim != 2 || out->ndim != 2 ||
        a->shape[1] != b->shape[0] ||
        out->shape[0] != a->shape[0] || out->shape[1] != b->shape[1])
        return TT_ERR_SHAPE;
    const size_t m = a->shape[0], k = a->shape[1], n = b->shape[1];
    const size_t block = 32;
    for (size_t i = 0; i < m * n; ++i) out->data[i] = 0.0f;
    for (size_t ii = 0; ii < m; ii += block)
        for (size_t kk = 0; kk < k; kk += block)
            for (size_t jj = 0; jj < n; jj += block) {
                size_t i_end = ii + block < m ? ii + block : m;
                size_t k_end = kk + block < k ? kk + block : k;
                size_t j_end = jj + block < n ? jj + block : n;
                for (size_t i = ii; i < i_end; ++i)
                    for (size_t p = kk; p < k_end; ++p) {
                        float av = a->data[i * k + p];
                        for (size_t j = jj; j < j_end; ++j)
                            out->data[i * n + j] += av * b->data[p * n + j];
                    }
            }
    return TT_OK;
}

tt_status tt_cross_entropy(const tt_tensor *p, const size_t *labels,
                           size_t batch, float *loss) {
    if (!p || !labels || !loss || !p->data || p->ndim != 2 ||
        p->shape[0] != batch || batch == 0) return TT_ERR_INVALID_ARGUMENT;
    size_t classes = p->shape[1];
    float total = 0.0f;
    for (size_t i = 0; i < batch; ++i) {
        if (labels[i] >= classes) return TT_ERR_INVALID_ARGUMENT;
        float v = p->data[i * classes + labels[i]];
        if (v < 1.0e-7f) v = 1.0e-7f;
        total -= logf(v);
    }
    *loss = total / (float)batch;
    return TT_OK;
}

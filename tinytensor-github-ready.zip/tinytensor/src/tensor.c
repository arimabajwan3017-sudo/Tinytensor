#include "tinytensor/tinytensor.h"
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

static tt_status tensor_metadata(tt_tensor *t, size_t ndim, const size_t *shape) {
    if (!t || !shape || ndim == 0 || ndim > TT_MAX_DIMS)
        return TT_ERR_INVALID_ARGUMENT;
    size_t count = 1;
    for (size_t i = 0; i < ndim; ++i) {
        if (shape[i] == 0 || count > SIZE_MAX / shape[i]) return TT_ERR_SHAPE;
        t->shape[i] = shape[i];
        count *= shape[i];
    }
    t->ndim = ndim;
    t->numel = count;
    t->strides[ndim - 1] = 1;
    for (size_t i = ndim - 1; i > 0; --i)
        t->strides[i - 1] = t->strides[i] * t->shape[i];
    return TT_OK;
}

const char *tt_status_string(tt_status s) {
    switch (s) {
        case TT_OK: return "success";
        case TT_ERR_INVALID_ARGUMENT: return "invalid argument";
        case TT_ERR_SHAPE: return "incompatible shape";
        case TT_ERR_OUT_OF_MEMORY: return "out of memory";
        default: return "unknown status";
    }
}

tt_status tt_tensor_create(tt_tensor *t, size_t ndim, const size_t *shape) {
    if (!t) return TT_ERR_INVALID_ARGUMENT;
    memset(t, 0, sizeof(*t));
    tt_status s = tensor_metadata(t, ndim, shape);
    if (s != TT_OK) return s;
    t->data = (float *)calloc(t->numel, sizeof(float));
    if (!t->data) return TT_ERR_OUT_OF_MEMORY;
    t->owns_data = true;
    return TT_OK;
}

tt_status tt_tensor_create_in_arena(tt_tensor *t, tt_arena *arena,
                                    size_t ndim, const size_t *shape) {
    if (!t || !arena) return TT_ERR_INVALID_ARGUMENT;
    memset(t, 0, sizeof(*t));
    tt_status s = tensor_metadata(t, ndim, shape);
    if (s != TT_OK) return s;
    t->data = (float *)tt_arena_alloc(arena, t->numel * sizeof(float),
                                      _Alignof(float));
    if (!t->data) return TT_ERR_OUT_OF_MEMORY;
    memset(t->data, 0, t->numel * sizeof(float));
    t->owns_data = false;
    return TT_OK;
}

void tt_tensor_free(tt_tensor *t) {
    if (!t) return;
    if (t->owns_data) free(t->data);
    memset(t, 0, sizeof(*t));
}

tt_status tt_tensor_fill(tt_tensor *t, float value) {
    if (!t || !t->data) return TT_ERR_INVALID_ARGUMENT;
    for (size_t i = 0; i < t->numel; ++i) t->data[i] = value;
    return TT_OK;
}

tt_status tt_tensor_copy(tt_tensor *dst, const tt_tensor *src) {
    if (!dst || !src || !dst->data || !src->data) return TT_ERR_INVALID_ARGUMENT;
    if (dst->numel != src->numel || dst->ndim != src->ndim)
        return TT_ERR_SHAPE;
    for (size_t i = 0; i < src->ndim; ++i)
        if (dst->shape[i] != src->shape[i]) return TT_ERR_SHAPE;
    memcpy(dst->data, src->data, src->numel * sizeof(float));
    return TT_OK;
}

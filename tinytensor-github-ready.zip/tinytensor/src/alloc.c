#include "tinytensor/tinytensor.h"
#include <stdint.h>
#include <stdlib.h>

tt_status tt_arena_init(tt_arena *arena, size_t capacity) {
    if (!arena || capacity == 0) return TT_ERR_INVALID_ARGUMENT;
    arena->memory = (unsigned char *)malloc(capacity);
    if (!arena->memory) return TT_ERR_OUT_OF_MEMORY;
    arena->capacity = capacity;
    arena->offset = 0;
    return TT_OK;
}

void tt_arena_reset(tt_arena *arena) {
    if (arena) arena->offset = 0;
}

void tt_arena_free(tt_arena *arena) {
    if (!arena) return;
    free(arena->memory);
    arena->memory = NULL;
    arena->capacity = 0;
    arena->offset = 0;
}

void *tt_arena_alloc(tt_arena *arena, size_t bytes, size_t alignment) {
    if (!arena || !arena->memory || bytes == 0 || alignment == 0 ||
        (alignment & (alignment - 1)) != 0) return NULL;
    uintptr_t base = (uintptr_t)arena->memory;
    uintptr_t current = base + arena->offset;
    uintptr_t aligned = (current + alignment - 1) & ~(uintptr_t)(alignment - 1);
    size_t next = (size_t)(aligned - base);
    if (next > arena->capacity || bytes > arena->capacity - next) return NULL;
    arena->offset = next + bytes;
    return (void *)aligned;
}

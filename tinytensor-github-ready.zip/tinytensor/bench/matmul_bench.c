#include "tinytensor/tinytensor.h"
#include <stdio.h>
#include <time.h>

int main(void) {
    const size_t n=256;
    size_t s[]={n,n};
    tt_tensor a,b,c;
    if(tt_tensor_create(&a,2,s)!=TT_OK || tt_tensor_create(&b,2,s)!=TT_OK ||
       tt_tensor_create(&c,2,s)!=TT_OK) return 1;
    for(size_t i=0;i<n*n;i++){a.data[i]=0.01f*(float)(i%17);b.data[i]=0.02f*(float)(i%13);}
    clock_t start=clock();
    for(int r=0;r<5;r++) if(tt_matmul(&a,&b,&c)!=TT_OK) return 1;
    double seconds=(double)(clock()-start)/(double)CLOCKS_PER_SEC;
    printf("matmul %zux%zu, 5 runs: %.6f s (CPU clock time)\\n",n,n,seconds);
    tt_tensor_free(&a);tt_tensor_free(&b);tt_tensor_free(&c);
    return 0;
}

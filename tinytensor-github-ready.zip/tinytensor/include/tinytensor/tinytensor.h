#ifndef TINYTENSOR_H
#define TINYTENSOR_H

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define TT_MAX_DIMS 8

typedef struct {
    float *data;
    size_t shape[TT_MAX_DIMS];
    size_t strides[TT_MAX_DIMS];
    size_t ndim;
    size_t numel;
    bool owns_data;
} tt_tensor;

typedef struct {
    unsigned char *memory;
    size_t capacity;
    size_t offset;
} tt_arena;

typedef enum {
    TT_OK = 0,
    TT_ERR_INVALID_ARGUMENT,
    TT_ERR_SHAPE,
    TT_ERR_OUT_OF_MEMORY
} tt_status;

const char *tt_status_string(tt_status status);
tt_status tt_arena_init(tt_arena *arena, size_t capacity);
void tt_arena_reset(tt_arena *arena);
void tt_arena_free(tt_arena *arena);
void *tt_arena_alloc(tt_arena *arena, size_t bytes, size_t alignment);

tt_status tt_tensor_create(tt_tensor *tensor, size_t ndim,
                           const size_t *shape);
tt_status tt_tensor_create_in_arena(tt_tensor *tensor, tt_arena *arena,
                                    size_t ndim, const size_t *shape);
void tt_tensor_free(tt_tensor *tensor);
tt_status tt_tensor_fill(tt_tensor *tensor, float value);
tt_status tt_tensor_copy(tt_tensor *dst, const tt_tensor *src);
tt_status tt_add(const tt_tensor *a, const tt_tensor *b, tt_tensor *out);
tt_status tt_relu(const tt_tensor *input, tt_tensor *out);
tt_status tt_softmax(const tt_tensor *input, tt_tensor *out);
tt_status tt_matmul(const tt_tensor *a, const tt_tensor *b, tt_tensor *out);
tt_status tt_cross_entropy(const tt_tensor *probabilities,
                           const size_t *labels, size_t batch,
                           float *loss);

#ifdef __cplusplus
}
#endif
#endif
